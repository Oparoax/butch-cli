from setuptools import setup

setup(
    name='butch_OS',
    version='1.0',
    packages=[''],
    url='',
    license='',
    author='jdawes',
    author_email='',
    description='Command line app for ttrpg \'cities without numbers\''
)
